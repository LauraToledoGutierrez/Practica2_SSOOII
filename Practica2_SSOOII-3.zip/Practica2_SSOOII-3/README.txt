Practica 2  SSOO II     2021/22     Cristian Ballesteros Serrano, Daniel Max Samson Samson, Laura Toledo Gutierrez

COMPILACION:

    La compilacion es bastante sencilla, primero debemos colocarnos dentro del terminal en el directorio raiz. 
Una vez dentro ejecutamos el comando "make" que se encarga de compilar ficheros y creara los directorios necesarios. 
Lo siguiente que hay que hacer es ejecutar "make ejecutar" que se encargara de ejecutar la practica.

        *IMPORTANTE: Para poder volver a ejecutar la practica deberas ejecutar el comando "make clean" 
	        y volver a repetir los pasos anterioresen el mismo orden.

En la carpeta raiz se encuentra:
	*include: donde se encuentra definitions.h, clases.h y colores.h
	*src: donde se encuentran el archivo .cpp
	*Libros_P2: los libros sobre los que realizamos las busquedas
